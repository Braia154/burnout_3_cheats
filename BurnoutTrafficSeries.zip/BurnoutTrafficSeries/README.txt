BURNOUT 3: TAKEDOWN (SLUS-21050) - TRAFFIC SERIES (8th car class)
==================================================================

EN
--
20 traffic vehicles playable as a new series, TRAFFIC, after Heavyweights in the
garage (Single Event / Multiplayer garages that list every series).

Install
  1. Copy everything inside game_files/ over the game's files (Host FS folder or
     rebuilt ISO). It adds pveh/TRAF/ and REPLACES pveh/vlist.bin and
     Data/Globalus.bin - back those two up first.
  2. Put cheats/bebf8793_traffic_series.pnach in PCSX2's cheats folder and enable
     the section [Traffic Series (8th class)].
  The files and the cheat only work together. Without the cheat the new cars have
  no physics/sound data; with the cheat but without the files the series is empty.

Notes
  - Do NOT leave a TRAFFIC car as the selected car in a save and then remove the
    mod: that save would point to a car that no longer exists.
  - Code cave used: 0x002382C0-0x002383C7 (table at 0x005192A8 and code at 0x00519528, both inside vlist), plus 0x001DC7CC-0x001DC817 and hooks at 0x0021AB40, 0x001B36E4, 0x001B36F4, 0x0030C13C, 0x0030C3F0, 0x0030B720,
    0x0030B82C, 0x003EB060, 0x003EAE88 and garage patches 0x0042BF24..0x0042DAD0.
    Other cheats writing there will conflict.
  - Globalus.bin is the original text file with duplicate strings shared and the
    40 new car names appended (smaller than the original).
  - Garage thumbnails: each car shows the picture of its physics donor.
  - "Vineyard Van Beta" (TRAFCAR6) is the Vineyard Van model from the June 8, 2004
    prototype, converted to the retail format. It replaces the US SUV.

PT
--
20 carros de trafego jogaveis numa serie nova, TRAFFIC, depois de Heavyweights na
garagem (Single Event / Multiplayer, nas garagens que mostram todas as series).

Instalacao
  1. Copie o conteudo de game_files/ por cima dos arquivos do jogo (pasta do Host
     FS ou ISO remontada). Cria pveh/TRAF/ e SUBSTITUI pveh/vlist.bin e
     Data/Globalus.bin - faca backup desses dois antes.
  2. Coloque cheats/bebf8793_traffic_series.pnach na pasta de cheats do PCSX2 e
     ligue a secao [Traffic Series (8th class)].
  Arquivos e cheat so funcionam juntos.

Observacoes
  - Nao deixe um carro TRAFFIC selecionado num save e depois remova o mod.
  - Miniatura na garagem: cada carro mostra a imagem do seu doador de fisica.
  - "Vineyard Van Beta" (TRAFCAR6) e o modelo da Vineyard Van do prototipo de
    8 de junho de 2004, convertido para o retail. Entrou no lugar do US SUV.
  - Cave e ganchos usados estao listados acima; outros cheats nesses enderecos
    vao conflitar.

Cars / Carros (slot - name - physics / camera / engine sound)
  "Tuk Tuk"      TRAFCAR1  COMP/Car18  physics COMP/Car2  camera HEVY/Car5  sound HEVY/Car2
  "Yugo"         TRAFCAR2  COMP/Car14  physics COMP/Car2  camera HEVY/Car5  sound HEVY/Car3
  "US Hatch"     TRAFCAR3  COMP/Car11  physics COMP/Car2  camera HEVY/Car5  sound HEVY/Car3
  "US Family Van" TRAFCAR4  HEVY/Car13  physics HEVY/Car1  camera HEVY/Car5  sound HEVY/Car3
  "US Sedan"     TRAFCAR5  COMP/Car13  physics MSCL/Car2  camera HEVY/Car5  sound HEVY/Car3
  "Vineyard Van Beta" TRAFCAR6  BETA/HEVY35 physics HEVY/Car5  camera HEVY/Car7  sound HEVY/Car6
  "Vineyard Van" TRAFCAR7  HEVY/Car35  physics HEVY/Car5  camera HEVY/Car6  sound HEVY/Car6
  "EU Family SUV" TRAFCAR8  COMP/Car12  physics HEVY/Car3  camera HEVY/Car5  sound HEVY/Car3
  "EU Van"       TRAFCAR9  HEVY/Car33  physics HEVY/Car5  camera HEVY/Car5  sound HEVY/Car5
  "AS Taxi"      TRAFCAR10 COMP/Car17  physics COMP/Car9  camera HEVY/Car5  sound HEVY/Car1
  "EU Taxi"      TRAFCAR11 COMP/Car16  physics COMP/Car9  camera HEVY/Car5  sound HEVY/Car1
  "Pick-up"      TRAFCAR12 HEVY/Car15  physics HEVY/Car2  camera HEVY/Car1  sound HEVY/Car1
  "US Taxi"      TRAFCAR13 COMP/Car15  physics COMP/Car9  camera HEVY/Car5  sound HEVY/Car1
  "Tourist Pick-up" TRAFCAR14 HEVY/Car31  physics HEVY/Car2  camera HEVY/Car5  sound HEVY/Car5
  "US Classic Sedan" TRAFCAR15 COMP/Car19  physics MSCL/Car1  camera HEVY/Car5  sound HEVY/Car3
  "Utility Truck" TRAFCAR16 HEVY/Car18  physics HEVY/Car4  camera HEVY/Car4  sound HEVY/Car4
  "Snow Plow Truck" TRAFCAR17 HEVY/Car32  physics HEVY/Car6  camera HEVY/Car36 sound HEVY/Car36
  "EU Bus"       TRAFCAR18 HEVY/Car20  physics HEVY/Car9  camera HEVY/Car9  sound HEVY/Car9
  "AS Bus"       TRAFCAR19 HEVY/Car21  physics HEVY/Car9  camera HEVY/Car9  sound HEVY/Car9
  "Motorhome"    TRAFCAR20 HEVY/Car34  physics HEVY/Car10 camera HEVY/Car9  sound HEVY/Car9

Credits / Creditos
------------------
  The cheat includes "Heavyweights always available" by escape209 (patch=1,EE,01E8EE94,extended,00000001):
  the TRAFFIC series comes after the Heavyweights page, so that page must be unlocked in every mode.
  O cheat inclui "Heavyweights always available", de escape209: a serie TRAFFIC vem depois da pagina
  Heavyweights, entao essa pagina precisa estar liberada em todos os modos.
